<?php
ob_start();
?>

<div class="min-h-screen bg-white flex">
    <!-- Left Side - Login Form -->
    <div class="flex-1 flex items-center justify-center p-8 lg:p-12">
        <div class="w-full max-w-md">

            <!-- Error Message -->
            <?php if (isset($error)): ?>
                <div class="mb-6 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
                    <div class="flex items-center">
                        <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"></path>
                        </svg>
                        <span><?= htmlspecialchars($error) ?></span>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Login Form -->
            <?php 
            $basePath = rtrim(dirname($_SERVER['SCRIPT_NAME']), '');
            $loginAction = $basePath . '/login';
            ?>
            <form method="POST" action="<?= $loginAction ?>" class="space-y-6">
                <input type="hidden" name="csrf_token" value="<?= Security::generateCSRFToken() ?>">
                
                <!-- Username Field -->
                <div>
                    <label for="username" class="block text-sm font-medium text-gray-700 mb-2">Username</label>
                    <input 
                        id="username" 
                        name="username" 
                        type="text" 
                        required 
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                        placeholder="Masukkan username"
                        autocomplete="username"
                    >
                </div>

                <!-- Password Field -->
                <div>
                    <label for="password" class="block text-sm font-medium text-gray-700 mb-2">Password</label>
                    <div class="relative">
                        <input 
                            id="password" 
                            name="password" 
                            type="password" 
                            required 
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors pr-12"
                            placeholder="Masukkan password"
                            autocomplete="current-password"
                        >
                        <button type="button" onclick="togglePassword()" class="absolute inset-y-0 right-0 pr-3 flex items-center">
                            <svg id="eyeIcon" class="w-5 h-5 text-gray-400 hover:text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>
                            </svg>
                        </button>
                    </div>
                </div>

                <!-- Login Button -->
                <button 
                    type="submit" 
                    class="w-full bg-blue-600 text-white font-medium py-3 rounded-lg hover:bg-blue-700 focus:ring-4 focus:ring-blue-200 transition-all duration-200"
                >
                    Masuk ke Dashboard
                </button>
            </form>
        </div>
    </div>

    <!-- Right Side - Illustration -->
    <div class="hidden lg:flex flex-1 bg-gradient-to-br from-blue-50 to-indigo-100 items-center justify-center p-12">
        <div class="max-w-lg text-center">
            <!-- Illustration -->
            <div class="mb-8">
                <div class="relative">
                    <!-- Main illustration container -->
                    <div class="w-80 h-80 mx-auto relative">
                        <!-- Background circle -->
                        <div class="absolute inset-0 bg-gradient-to-br from-blue-200 to-indigo-300 rounded-full opacity-20"></div>
                        
                        <!-- IoT devices illustration -->
                        <div class="absolute inset-0 flex items-center justify-center">
                            <div class="grid grid-cols-3 gap-4">
                                <!-- Sensor icons -->
                                <div class="w-16 h-16 bg-white rounded-xl shadow-lg flex items-center justify-center">
                                    <span class="text-2xl">📡</span>
                                </div>
                                <div class="w-16 h-16 bg-white rounded-xl shadow-lg flex items-center justify-center">
                                    <span class="text-2xl">🌡️</span>
                                </div>
                                <div class="w-16 h-16 bg-white rounded-xl shadow-lg flex items-center justify-center">
                                    <span class="text-2xl">💨</span>
                                </div>
                                <div class="w-16 h-16 bg-white rounded-xl shadow-lg flex items-center justify-center">
                                    <span class="text-2xl">🚿</span>
                                </div>
                                <div class="w-20 h-20 bg-blue-600 rounded-xl shadow-xl flex items-center justify-center transform scale-110">
                                    <span class="text-3xl text-white">📊</span>
                                </div>
                                <div class="w-16 h-16 bg-white rounded-xl shadow-lg flex items-center justify-center">
                                    <span class="text-2xl">🔒</span>
                                </div>
                                <div class="w-16 h-16 bg-white rounded-xl shadow-lg flex items-center justify-center">
                                    <span class="text-2xl">💡</span>
                                </div>
                                <div class="w-16 h-16 bg-white rounded-xl shadow-lg flex items-center justify-center">
                                    <span class="text-2xl">🔔</span>
                                </div>
                                <div class="w-16 h-16 bg-white rounded-xl shadow-lg flex items-center justify-center">
                                    <span class="text-2xl">📱</span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Connection lines -->
                        <svg class="absolute inset-0 w-full h-full" viewBox="0 0 320 320">
                            <defs>
                                <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                                    <stop offset="0%" style="stop-color:#3B82F6;stop-opacity:0.3" />
                                    <stop offset="100%" style="stop-color:#6366F1;stop-opacity:0.1" />
                                </linearGradient>
                            </defs>
                            <path d="M160 80 L160 160 M80 160 L240 160 M120 120 L200 200 M200 120 L120 200" 
                                  stroke="url(#lineGradient)" 
                                  stroke-width="2" 
                                  stroke-dasharray="5,5" 
                                  fill="none">
                                <animate attributeName="stroke-dashoffset" 
                                         values="0;10" 
                                         dur="2s" 
                                         repeatCount="indefinite"/>
                            </path>
                        </svg>
                    </div>
                </div>
            </div>
            
            <!-- Text content -->
            <h2 class="text-3xl font-bold text-gray-900 mb-4">Smart Monitoring</h2>
            <p class="text-lg text-gray-600 mb-6">
                Sistem monitoring kamar mandi berbasis IoT dengan teknologi sensor canggih untuk menjaga kebersihan dan kenyamanan.
            </p>
            
            <!-- Features -->
            <div class="grid grid-cols-2 gap-4 text-left">
                <div class="flex items-center space-x-3">
                    <div class="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                        <svg class="w-5 h-5 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                        </svg>
                    </div>
                    <span class="text-sm text-gray-700">Real-time Monitoring</span>
                </div>
                <div class="flex items-center space-x-3">
                    <div class="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                        <svg class="w-5 h-5 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                        </svg>
                    </div>
                    <span class="text-sm text-gray-700">IoT Integration</span>
                </div>
                <div class="flex items-center space-x-3">
                    <div class="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                        <svg class="w-5 h-5 text-purple-600" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                        </svg>
                    </div>
                    <span class="text-sm text-gray-700">Reward System</span>
                </div>
                <div class="flex items-center space-x-3">
                    <div class="w-8 h-8 bg-yellow-100 rounded-lg flex items-center justify-center">
                        <svg class="w-5 h-5 text-yellow-600" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                        </svg>
                    </div>
                    <span class="text-sm text-gray-700">Analytics Dashboard</span>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function togglePassword() {
    const passwordInput = document.getElementById('password');
    const eyeIcon = document.getElementById('eyeIcon');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        eyeIcon.innerHTML = `
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.878 9.878L3 3m6.878 6.878L21 21"></path>
        `;
    } else {
        passwordInput.type = 'password';
        eyeIcon.innerHTML = `
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>
        `;
    }
}

// Form enhancements
document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form');
    const submitBtn = form.querySelector('button[type="submit"]');
    
    form.addEventListener('submit', function(e) {
        submitBtn.innerHTML = `
            <div class="flex items-center justify-center space-x-2">
                <div class="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                <span>Memproses...</span>
            </div>
        `;
        submitBtn.disabled = true;
    });
    
    console.log('🚿 SANIPOINT Login Page Loaded');
});
</script>

<?php
$content = ob_get_clean();
$title = 'Login - SANIPOINT IoT Monitoring System';
include __DIR__ . '/../layouts/main.php';
?>