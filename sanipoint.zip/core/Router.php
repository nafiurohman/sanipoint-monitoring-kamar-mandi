<?php
class Router {
    private $routes = [];
    
    public function add($route, $handler) {
        $this->routes[$route] = $handler;
    }
    
    public function getRoutes() {
        return $this->routes;
    }
    
    public function dispatch($uri) {
        // Parse the URI to get just the path
        $uri = parse_url($uri, PHP_URL_PATH);
        
        // Remove base path dynamically
        $basePath = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
        if ($basePath && strpos($uri, $basePath) === 0) {
            $uri = substr($uri, strlen($basePath));
        }
        
        // Normalize URI
        $uri = rtrim($uri, '/');
        if ($uri === '') $uri = '/';
        
        console_log("🎯 Routing URI: '$uri' (Original: {$_SERVER['REQUEST_URI']})");
        
        // Check if route exists
        if (isset($this->routes[$uri])) {
            console_log("✅ Route found: $uri");
            $handler = $this->routes[$uri];
            if (is_callable($handler)) {
                $handler();
            } else {
                $this->callHandler($handler);
            }
        } else {
            console_log("❌ Route not found: $uri");
            console_log("🗺 Available routes: " . implode(', ', array_keys($this->routes)));
            $this->notFound();
        }
    }
    
    private function callHandler($handler) {
        list($controller, $method) = explode('@', $handler);
        $controllerFile = "controllers/{$controller}.php";
        
        console_log("🎮 Calling: {$controller}@{$method}");
        
        if (file_exists($controllerFile)) {
            require_once $controllerFile;
            if (class_exists($controller)) {
                $controllerInstance = new $controller();
                if (method_exists($controllerInstance, $method)) {
                    $controllerInstance->$method();
                } else {
                    console_log("⚠️ Method not found: {$controller}::{$method}");
                    $this->notFound();
                }
            } else {
                console_log("⚠️ Class not found: {$controller}");
                $this->notFound();
            }
        } else {
            console_log("⚠️ Controller file not found: {$controllerFile}");
            $this->notFound();
        }
    }
    
    private function notFound() {
        http_response_code(404);
        console_log("🚫 404 Error - Page not found");
        $this->render404();
    }
    
    private function render404() {
        $title = '404 - Halaman Tidak Ditemukan';
        $content = $this->get404Content();
        
        // Check if main layout exists
        if (file_exists('views/layouts/main.php')) {
            include 'views/layouts/main.php';
        } else {
            // Fallback to inline 404 page
            echo $this->getInline404();
        }
    }
    
    private function get404Content() {
        return '
        <div class="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center p-4">
            <div class="text-center max-w-md">
                <div class="mx-auto w-32 h-32 bg-gradient-to-br from-red-500 to-pink-600 rounded-3xl flex items-center justify-center mb-8 shadow-2xl">
                    <i class="fas fa-exclamation-triangle text-white text-4xl"></i>
                </div>
                <h1 class="text-8xl font-bold text-white mb-4">404</h1>
                <h2 class="text-2xl font-semibold text-slate-300 mb-4">Halaman Tidak Ditemukan</h2>
                <p class="text-slate-400 mb-8 leading-relaxed">Maaf, halaman yang Anda cari tidak dapat ditemukan atau telah dipindahkan.</p>
                <a href="/" class="inline-flex items-center px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold rounded-2xl hover:from-blue-600 hover:to-purple-700 transform hover:scale-105 transition-all duration-200 shadow-xl">
                    <i class="fas fa-home mr-3"></i>
                    Kembali ke Beranda
                </a>
            </div>
        </div>';
    }
    
    private function getInline404() {
        $basePath = rtrim(dirname($_SERVER['SCRIPT_NAME']), '');
        return '<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Halaman Tidak Ditemukan | SANIPOINT</title>
    <style>
        body { 
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            margin: 0; padding: 0;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container {
            text-align: center;
            background: white;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            max-width: 500px;
        }
        .error-code { font-size: 6em; color: #e74c3c; margin: 0; }
        .error-message { color: #666; margin: 20px 0; }
        .btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 50px;
            text-decoration: none;
            display: inline-block;
            font-weight: 600;
            transition: transform 0.3s ease;
            margin: 5px;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.2);
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="error-code">404</h1>
        <h2>Halaman Tidak Ditemukan</h2>
        <p class="error-message">Maaf, halaman yang Anda cari tidak dapat ditemukan.</p>
        <a href="' . $basePath . '/" class="btn">🏠 Kembali ke Beranda</a>
        <a href="' . $basePath . '/auth/login" class="btn">🚀 Login</a>
    </div>
    <script>
        console.log("🚫 404 - Page not found");
        console.log("🔗 Available links: Home, Login");
    </script>
</body>
</html>';
    }
}
?>